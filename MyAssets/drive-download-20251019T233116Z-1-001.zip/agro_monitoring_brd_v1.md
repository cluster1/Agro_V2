# Agro-Livestock Monitoring System (Hybrid MariaDB + InfluxDB)

## 1. Ringkasan Eksekutif
Sistem **Agro-Livestock Monitoring** dikembangkan untuk membantu petani dan peternak memantau kondisi lingkungan pertanian dan peternakan secara real-time menggunakan teknologi **IoT**. Sistem ini menerapkan arsitektur hybrid dengan **MariaDB** untuk metadata dan **InfluxDB** untuk data sensor berkala.

Model integrasi menggunakan strategi **One-way flow**, di mana data sensor dikirim dari perangkat IoT ke InfluxDB, sementara metadata dan nilai terbaru disimpan di MariaDB untuk kebutuhan laporan dan dashboard.

---

## 2. Tujuan Bisnis
- Meningkatkan efisiensi pemantauan lahan dan kandang dengan sensor otomatis.
- Menyediakan analisis kondisi lingkungan dan ternak secara cepat.
- Memungkinkan pengelolaan banyak lokasi dan pengguna (multi-tenant & multi-user).
- Mendukung pengambilan keputusan berbasis data (data-driven decision making).

---

## 3. Ruang Lingkup Sistem

### In Scope
- Monitoring sensor IoT: suhu, kelembapan, pH, curah hujan, gas amonia, CO₂.
- Integrasi cuaca eksternal (BMKG API).
- Notifikasi otomatis kondisi abnormal.
- Upload foto/video kondisi lapangan.
- Dukungan multi-tenant (koperasi, kelompok tani, peternakan).
- Dukungan multi-user (admin, petani, investor).

### Out of Scope
- Pengendalian perangkat otomatis (actuator control).
- Transaksi keuangan / hasil panen.

---

## 4. Arsitektur Database

### MariaDB (Relational Metadata)
Berisi data:
- `tm_tenant`, `tm_user` → multi-tenant dan user management
- `tm_site`, `tm_cluster` → lokasi utama dan unit operasional (kandang, kolam, lahan)
- `tm_device`, `td_sensor`, `td_device_sensor` → metadata perangkat IoT
- `tm_sensor_read_update` → cache nilai terbaru
- `tm_alarm`, `tr_alarm_code` → sistem notifikasi
- `tm_weather` → data cuaca eksternal (BMKG)
- `tm_livestock`, `tm_livestock_activity` → data ternak individu dan aktivitas
- `tm_site_media` → foto/video lapangan

### InfluxDB (Time-Series Data)
Berisi data:
- `sensor_read` → data hasil pembacaan sensor IoT (per detik / menit)
- `log_receive` → log payload MQTT mentah

---

## 5. Strategi Sinkronisasi (One-way Flow)
1. IoT Device mengirim data → MQTT Broker (Mosquitto/EMQX).
2. Data Collector Service (Python/Node.js) membaca payload MQTT.
3. Data Collector:
   - Menulis data ke **InfluxDB** (bucket: `sensor_read`).
   - Mengupdate nilai terakhir di **MariaDB** (`tm_sensor_read_update`).
4. Dashboard dan API hanya membaca data:
   - Dari **InfluxDB** untuk grafik / tren waktu.
   - Dari **MariaDB** untuk metadata, status perangkat, dan laporan.

---

## 6. Integrasi Data
### Contoh Payload MQTT → InfluxDB
```json
{
  "tenant_id": "TEN001",
  "site_id": "SITE001",
  "cluster_id": "CL001",
  "dev_id": "DEV001",
  "ds_id": "S01",
  "timestamp": "2025-10-17T09:00:00Z",
  "value": 29.5,
  "status": 1
}
```

### Mapping ke MariaDB
| Kolom MariaDB | Sumber Data | Keterangan |
|----------------|--------------|-------------|
| tenant_id | payload | referensi tenant |
| cluster_id | payload | referensi cluster |
| ds_id | payload | referensi sensor |
| read_update_value | payload.value | nilai terbaru sensor |
| read_update_date | payload.timestamp | waktu pembaruan terakhir |

---

## 7. Alur Data (Flow Diagram)
```mermaid
flowchart TD
  A[IoT Device] -->|MQTT JSON Payload| B[MQTT Broker]
  B --> C[Data Collector Service]
  C -->|Write| D[InfluxDB - sensor_read]
  C -->|Update| E[MariaDB - tm_sensor_read_update]
  D --> F[Dashboard (Grafik Tren)]
  E --> G[Dashboard (Metadata & Nilai Terkini)]
```

---

## 8. Teknologi yang Digunakan
| Komponen | Teknologi |
|-----------|------------|
| **MQTT Broker** | Mosquitto / EMQX |
| **Data Collector** | Node.js (MQTT.js + Influx client) / Python (paho-mqtt + influxdb-client) |
| **Database Time-series** | InfluxDB 2.x |
| **Database Relasional** | MariaDB 10.6+ |
| **Frontend Dashboard** | React.js / Vue.js |
| **Backend API** | Node.js / FastAPI |

---

## 9. Keamanan dan Skalabilitas
- Komunikasi data: HTTPS + MQTT TLS.
- Setiap device memiliki `dev_token` unik.
- Retensi data Influx: 30 hari (bisa diperpanjang sesuai kebutuhan).
- Backup metadata (MariaDB) dilakukan harian.
- Load balancing MQTT broker untuk ribuan perangkat.

---

## 10. Kesimpulan
Dengan arsitektur hybrid ini:
- **InfluxDB** menangani data sensor skala besar (real-time, time-series).
- **MariaDB** menangani metadata, user, dan laporan bisnis.
- Sistem tetap **modular, cepat, dan aman**, cocok untuk ekspansi besar ke ribuan sensor dan cluster pertanian/peternakan.

---

## 11. ERD Ringkas (MariaDB)
```sql
-- ERD Relasional untuk Metadata (MariaDB)

-- Tenant dan User
CREATE TABLE tm_tenant (...);
CREATE TABLE tm_user (...);

-- Lokasi dan Cluster
CREATE TABLE tm_site (...);
CREATE TABLE tm_cluster (...);

-- IoT Perangkat dan Sensor
CREATE TABLE tm_device (...);
CREATE TABLE td_sensor (...);
CREATE TABLE td_device_sensor (...);

-- Data Sensor Ringkasan
CREATE TABLE tm_sensor_read_update (...);

-- Alarm dan Cuaca
CREATE TABLE tm_alarm (...);
CREATE TABLE tr_alarm_code (...);
CREATE TABLE tm_weather (...);

-- Data Ternak dan Aktivitas
CREATE TABLE tm_livestock (...);
CREATE TABLE tm_livestock_activity (...);

-- Media Lapangan
CREATE TABLE tm_site_media (...);
```

